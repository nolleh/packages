#include <eosio.bios/eosio.bios.hpp>

EOSIO_ABI( eosio::bios, (setpriv)(setalimits)(setglimits)(setprods)(setparams)(reqauth) )
