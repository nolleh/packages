/** @file 
 *    @copyright defined in eos/LICENSE 
 *
 * \warning This file is machine generated. DO NOT EDIT.  See core_symbol.hpp.in for changes.
 */

#define CORE_SYMBOL SY(4,)
#define CORE_SYMBOL_NAME ""
