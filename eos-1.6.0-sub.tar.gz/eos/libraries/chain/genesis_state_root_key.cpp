/**
 *  @file
 *  @copyright defined in eos/LICENSE
 */

#include <eosio/chain/genesis_state.hpp>

namespace eosio { namespace chain {

const string genesis_state::eosio_root_key = "";

} } // namespace eosio::chain
