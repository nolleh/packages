#pragma once

/// VERSION 1.6.1
namespace eosio {
   enum version {
      MAJOR 1,
      MINOR 6,
      PATCH 1
   };
}
